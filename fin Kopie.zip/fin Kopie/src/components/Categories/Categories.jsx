import React from 'react';
import { Link } from 'react-router-dom';
import "../Categories/Categories.scss";

function Categories() {
  const categories = [
    { id: 1, title: 'Fertilizer', image: '/img.png' },
    { id: 2, title: 'Protective products and septic tanks', image: '/img-2.png' },
    { id: 3, title: 'Planting material', image: '/img-3.png' },
    { id: 4, title: 'Tools and equipment', image: '/img-33.png' },
  ];

  return (
    <section className="categories-section">
      <div className="categories-title">
        <h2>Categories</h2>
      </div>

      <div className="categories-grid">
        {categories.map((cat) =>
          cat.title === 'Tools and equipment' ? (
            <Link
              to="/tools-and-equipment"
              key={cat.id}
              className="category-card"
              style={{ textDecoration: 'none', color: 'inherit' }}
            >
              <img src={cat.image} alt={cat.title} className="category-image" />
              <div className="category-label">{cat.title}</div>
            </Link>
          ) : (
            <div key={cat.id} className="category-card">
              <img src={cat.image} alt={cat.title} className="category-image" />
              <div className="category-label">{cat.title}</div>
            </div>
          )
        )}
      </div>
    </section>
  );
}

export default Categories;
