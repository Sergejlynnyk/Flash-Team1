import React from 'react';
import './DiscountForm.scss';

export default function DiscountForm() {
  return (
    <div className="discount-section">
      <div className="discount-content">
        <h2 className="discount-title">5% off on the first order</h2>
        <form className="discount-form">
          <input type="text" className="discount-input" placeholder="Name" required />
          <input type="tel" className="discount-input" placeholder="Phone number" required />
          <input type="email" className="discount-input" placeholder="Email" required />
          <button type="submit" className="discount-button">Get a discount</button>
        </form>
      </div>
      <div className="discount-image">
        <img src="/image11.png" alt="Hands with garden tools" />
      </div>
    </div>
  );
}
