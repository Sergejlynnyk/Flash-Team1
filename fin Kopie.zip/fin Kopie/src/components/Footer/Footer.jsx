import React from 'react';
import './Footer.scss';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faInstagram } from '@fortawesome/free-brands-svg-icons';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__header">Contact</div>

      <div className="footer__content">
        <div className="footer__left">
          <div className="footer__row footer__row--150">
            <div className="footer__textblock">
              <div className="footer__label">Phone</div>
              <div className="footer__phone">+49 999 999 99 99</div>
            </div>

            <div className="footer__socials">
              <div className="footer__label">Socials</div>
              <div className="footer__icons">
                <a
                  href="https://www.facebook.com/deinprofil"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="footer__icon-link"
                >
                  <FontAwesomeIcon icon={faFacebook} className="footer__icon" />
                </a>
                <a
                  href="https://www.instagram.com/deinprofil"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="footer__icon-link"
                >
                  <FontAwesomeIcon icon={faInstagram} className="footer__icon" />
                </a>
              </div>
            </div>
          </div>

          <div className="footer__row footer__row--194">
            <div className="footer__address">
              <div className="footer__label">Address</div>
              <div className="footer__info">
                
                  
                  Linkstraße 2, 8 OG,<br />
                  10 785, Berlin, Deutschland
                
              </div>
            </div>

            <div className="footer__hours">
              <div className="footer__label">Working Hours</div>
              <div className="footer__info">24 hours a day</div>
            </div>
          </div>
        </div>
      </div>

    
      <div className="footer__map">
        <a
          href="https://www.google.com/maps?q=Linkstraße+2,+8+OG,+10785+Berlin,+Deutschland"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img
            src="/8c44469ded4831f43dac39d4ba75577681b164f3.png"
            alt="Map to location"
            className="footer__map-img"
          />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
